const sdk = require('node-appwrite');

module.exports = async function (context) {
    // 1. Khởi tạo Client với quyền Admin (Sử dụng API Key)
    const client = new sdk.Client()
        .setEndpoint(process.env.APPWRITE_FUNCTION_ENDPOINT)
        .setProject(process.env.APPWRITE_FUNCTION_PROJECT_ID)
        .setKey(process.env.APPWRITE_API_KEY);

    const users = new sdk.Users(client);

    // 2. Lấy userId từ body yêu cầu
    let userId;
    try {
        const payload = JSON.parse(context.req.body);
        userId = payload.userId;
    } catch (e) {
        return context.res.json({ error: 'Invalid JSON body' }, 400);
    }

    if (!userId) {
        return context.res.json({ error: 'Missing userId' }, 400);
    }

    try {
        // 3. Thực hiện xóa người dùng trong Auth
        await users.delete(userId);
        context.log(`Successfully deleted user: ${userId}`);

        return context.res.json({
            status: 'success',
            message: `User ${userId} has been deleted from Authentication.`
        });
    } catch (err) {
        context.error(`Error deleting user: ${err.message}`);
        return context.res.json({
            status: 'error',
            message: err.message
        }, 500);
    }
};
